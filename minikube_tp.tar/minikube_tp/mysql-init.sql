CREATE DATABASE IF NOT EXISTS football_db;
USE football_db;
CREATE TABLE IF NOT EXISTS players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    position VARCHAR(50),
    age INT,
    nationality VARCHAR(50),
    club VARCHAR(100)
);
INSERT INTO players (name, position, age, nationality, club) VALUES
('Lionel Messi', 'Forward', 36, 'Argentina', 'Inter Miami'),
('Kylian Mbappé', 'Forward', 25, 'France', 'Paris Saint-Germain'),
('Kevin De Bruyne', 'Midfielder', 32, 'Belgium', 'Manchester City'),
('Virgil van Dijk', 'Defender', 32, 'Netherlands', 'Liverpool'),
('Thibaut Courtois', 'Goalkeeper', 31, 'Belgium', 'Real Madrid');
CREATE USER 'webuser'@'%' IDENTIFIED BY 'webpassword';
GRANT ALL PRIVILEGES ON football_db.* TO 'webuser'@'%';
FLUSH PRIVILEGES;
