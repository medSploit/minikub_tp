<?php
$servername = "mysql-service.sports-app.svc.cluster.local";
$username = "webuser";
$password = "webpassword";
$dbname = "football_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM players";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr><th>Name</th><th>Position</th><th>Age</th><th>Nationality</th><th>Club</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . htmlspecialchars($row["name"]) . "</td><td>" . 
             htmlspecialchars($row["position"]) . "</td><td>" . 
             htmlspecialchars($row["age"]) . "</td><td>" . 
             htmlspecialchars($row["nationality"]) . "</td><td>" . 
             htmlspecialchars($row["club"]) . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>
